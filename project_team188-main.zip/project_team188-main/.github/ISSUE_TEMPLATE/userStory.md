---
name: User Story
about: Describe a feature to be implemented or defect to be fixed.
title: '[User Story] <title>'
labels: story
assignees: ''

---

### User story summary:
<!-- Should include Role/Goal/Benefit. -->

### Definitions of done:
<!-- Concrete description of how the user story will be validated. Can contain specific examples of expected behaviours. -->

### Engineering tasks:
<!--
The tasks that need to be accomplished to build and validate the user story:
1. step 1
1. step 2
1. step 3...
-->
